HDBLAST research program — licensing
Copyright (c) 2025–2026 Ricardo Maldonado

This repository contains two kinds of material, licensed separately:

1. Text, figures, documents and data (for example all .md, .pdf, .png, .svg,
   .json, .csv and .txt files, and the website under site/) are licensed under
   the Creative Commons Attribution 4.0 International License (CC BY 4.0).
   You may share and adapt this material for any purpose, provided you give
   appropriate credit to Ricardo Maldonado, link to the license, and indicate
   if changes were made.
   Summary: https://creativecommons.org/licenses/by/4.0/
   Legal code: https://creativecommons.org/licenses/by/4.0/legalcode

2. Source code (for example all .py files and .github/workflows) is licensed
   under the MIT License, reproduced below.

Third-party material cited or bundled in this repository keeps its own license.

-------------------------------------------------------------------------------
MIT License

Copyright (c) 2025–2026 Ricardo Maldonado

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
